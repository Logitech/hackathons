# LogiInsight Webcam — PC Python SDK

**Version 1.5.0** · Windows, macOS and Linux · Python 3.9+

Python SDK and examples for the LogiInsight hackathon webcam. From a normal PC you can:

* read the **RGB** video stream with OpenCV,
* read the **near-infrared (IR)** video stream: a monochrome sensor that responds to a
  wide range of near-infrared wavelengths, lit by the camera's own illuminator,
* read the on-device **AI results** (face box and 478-point face mesh) and switch the
  models on and off over USB networking,
* record the camera's **microphone** (2 channels) and look at its power spectrum.

The full reference is **[`docs/API.md`](docs/API.md)**.

> **No Conda / Anaconda.** Use `uv` or plain `pip` + `venv`, as shown below.

---

## 1. Install

Run the commands in this folder. Pick one way.

**uv (recommended)** — [install uv](https://docs.astral.sh/uv/getting-started/installation/)

```bash
uv sync                      # creates .venv and installs the dependencies
uv run python example_IR.py  # run any script through uv
```

**pip + venv**

```bash
# Linux / macOS
python3 -m venv .venv && source .venv/bin/activate
# Windows
#   py -m venv .venv
#   .venv\Scripts\activate
pip install -r requirements.txt
```

Dependencies: `paramiko`, `numpy`, `opencv-python` (the normal build, **not**
`opencv-python-headless`, because the examples open windows), and for the microphone
`sounddevice`, `scipy` and `matplotlib`.

**Linux only:** the microphone needs the PortAudio system library, otherwise importing
`sounddevice` fails with `PortAudio library not found`:

```bash
sudo apt install libportaudio2
```

---

## 2. Plug in and check the video (no network setup needed)

Connect the camera with a USB 3 cable. Video works immediately. The camera shows up as
several cameras (names start with the product name, `LVNext` by default):

| Camera name | What it is | Used by this SDK |
|---|---|---|
| `… Camera` | RGB sensor: MJPG / YUY2 / NV12 | `example.py`, `example2.py` |
| `… CPD Camera` | near-infrared sensor, MJPG, **portrait** frames | `example_IR.py` |
| `… Hello Camera` | Windows Hello IR stream | not used: leave it to Windows Hello |

```bash
uv run python example_IR.py          # live near-infrared view with contrast / threshold modes
```

* macOS: allow the camera for your terminal (System Settings → Privacy & Security → Camera).
* Windows: Settings → Privacy & security → Camera → allow desktop apps.
* Linux: your user must be in the `video` group.

If the wrong camera opens (for example a laptop's built-in webcam), pass
`--device <index>`; try 0, 1, 2 … until the picture is right.

### Microphone (no network setup either)

The camera is also a USB microphone (`LVNext Microphone` by default). It sends **2
channels** to the PC: raw 16-bit samples at 48 kHz, no noise suppression or other
processing. Record 10 seconds and save a `.wav` plus a power-spectrum `.png`:

```bash
uv run python example_audio.py             # files go to ./audio_captures/
uv run python example_audio.py --list      # which input devices exist
```

Allow microphone access for your terminal (macOS: System Settings → Privacy & Security →
Microphone; Windows: Settings → Privacy & security → Microphone). On Windows the same
microphone can be listed once per audio host API with different channel counts (`WASAPI`
shows 2, `MME` / `DirectSound` / `WDM-KS` show 6). Only channels 1 and 2 carry audio; add
`--channels 2` to record just those. More in [`docs/API.md`](docs/API.md#11-audio-usb-microphone).

---

## 3. AI data over USB networking (RGB examples)

`example.py` and `example2.py` also talk to the camera over SSH/SFTP through a virtual
Ethernet adapter that the camera creates (USB NCM). The camera has the fixed address
**`192.168.1.10`**. Your PC needs an address in the same subnet: **`192.168.1.20`**, mask
`255.255.255.0`, and **no gateway** (so your Wi-Fi internet keeps working).

| OS | How |
|---|---|
| Linux | `ip -br link` to find the new adapter (`usb0` or `enx…`), then `sudo ip addr add 192.168.1.20/24 dev <adapter>` and `sudo ip link set <adapter> up` |
| macOS | System Settings → Network → the new USB Ethernet adapter → Details → TCP/IP → *Configure IPv4: Manually*, address `192.168.1.20`, mask `255.255.255.0`, router empty |
| Windows | Settings → Network & internet → Advanced network settings → the new Ethernet adapter → Edit IP assignment → Manual, address `192.168.1.20`, prefix length `24`, no gateway. Or, in an administrator terminal: `netsh interface ip set address "<adapter name>" static 192.168.1.20 255.255.255.0` |

Check with `ping 192.168.1.10`. If your home or campus Wi-Fi also uses `192.168.1.x`, the
addresses can collide; see *Troubleshooting* in [`docs/API.md`](docs/API.md#12-troubleshooting).

The SSH login is the one printed on your hackathon kit. **Do not put it in code**; export it:

```bash
export LOGIWEBCAM_PASSWORD='<password from your kit>'          # Linux / macOS
set LOGIWEBCAM_PASSWORD=<password from your kit>               # Windows cmd
```

(`--user` and `--password` exist too; the default user is `hackathon`.)

```bash
uv run python example.py --face-mesh                 # 10 annotated PNG+JSON pairs in ./captures
uv run python example.py --face-mesh --frames 30
uv run python example2.py --face-mesh                # live window with overlays (q / ESC quits)
```

---

## 4. Scripts

| Script | Purpose | Needs SSH |
|---|---|---|
| `example.py` | RGB: capture frames + AI JSON, save annotated PNG/JSON pairs (`--device-snapshot` for exactly paired frames) | yes |
| `example2.py` | RGB: live window with face box / mesh overlays | yes |
| `example_IR.py` | Near-infrared live view: `raw`, contrast `stretch`, `clahe`, `threshold`, `otsu` (keys: `m` mode, `+`/`-` threshold, `s` save, `q` quit) | no |
| `example_audio.py` | Microphone: record 10 s (`--duration`), save a multi-channel `.wav` and a per-channel power-spectrum `.png`, print RMS / peak / strongest frequency | no |
| `logiwebcam.py` | The client library (`LogiWebcamClient`) | — |
| `camera_utils.py` | Camera discovery / opening helpers used by the IR example | — |
| `audio_utils.py` | Microphone discovery, multi-channel capture, power spectrum, WAV / PNG export | — |

All scripts stop cleanly on **Ctrl+C** (the camera is released and windows are closed).

```bash
uv run python example_IR.py --mode clahe
uv run python example_IR.py --width 1024 --height 1280
```

---

## 5. Things worth knowing

* **AI results only exist while the RGB stream is open as MJPG.** On macOS (AVFoundation)
  and Windows (MSMF) OpenCV often ignores the MJPG request and you get raw video; the
  scripts warn when that happens. Set the size *before* the format (the examples do).
* **Coordinates are stream pixels**: pixels of the video size you opened (for example
  1920×1080). You can draw them directly on the frame.
* **The IR picture is portrait and grey** (256×320, 512×640 or 1024×1280).
* **RGB and IR can run together, but not both at full rate with the AI.** With RGB as MJPG
  (needed for the AI) each stream typically runs at about 15 fps, or the IR stream at about
  1 fps. With RGB as NV12 or YUY2 both streams run at 30 fps, but the AI is off. Open the
  RGB stream first.
* At most one face is reported per result.

## 6. Troubleshooting

| Symptom | Fix |
|---|---|
| `No near-infrared (CPD) camera found` | Check the cable, close apps that use the camera, check the OS camera permission; try `--device 0`, `1`, `2` … |
| IR example shows a colour or landscape picture | Wrong camera: choose another `--device`. |
| `ERROR: SSH password … required` | Export `LOGIWEBCAM_PASSWORD` (or pass `--password`). |
| `Failed to connect to 192.168.1.10` | The PC's USB-network adapter has no `192.168.1.x` address yet (section 3). |
| AI JSON never changes / `timestamp_ms` frozen | The RGB stream is not MJPG, or no program is reading the RGB stream. |
| `Cannot open … camera` on Linux | `ls /dev/video*`; add your user to the `video` group, log out and in. |
| macOS: black window / no frames | Allow Camera access for the terminal app, then restart it. |
| `PortAudio library not found` (Linux) | `sudo apt install libportaudio2` |
| `example_audio.py`: no microphone found / silent channels | Allow Microphone access for the terminal app; run `--list` and choose the camera's entry with `--device`; on Windows the entries differ in channel count (see above). |

More in [`docs/API.md`](docs/API.md#12-troubleshooting).

## License

MIT, see the `LICENSE` file. Copyright (c) 2026 Logitech Europe S.A.
