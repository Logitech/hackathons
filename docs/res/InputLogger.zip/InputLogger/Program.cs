﻿using System;
using System.Windows.Forms;

namespace InputLogger
{
    /// <summary>
    /// Basic console app which dumps keyboard and mouse events on Windows.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            using (var logger = new InputLogger())
            {
                logger.KeyEvent += (sender, message, keys, scanCode, time) =>
                {
                    Console.WriteLine(string.Format("{0} [vKey={1} scanCode={2} time={3}]", message, keys, scanCode, time));

                    if (keys == Keys.Enter)
                    {
                        Console.WriteLine("Exiting");
                        Application.Exit();
                    }
                };

                logger.MouseEvent += (sender, message, location, data, time) =>
                {
                    Console.WriteLine(string.Format("{0} [(X={1}, Y={2}) data={3} time={4}", message, location.X, location.Y, data, time));
                };

                Console.WriteLine("Press <ENTER> to exit");
                Application.Run();
            }
        }
    }
}
