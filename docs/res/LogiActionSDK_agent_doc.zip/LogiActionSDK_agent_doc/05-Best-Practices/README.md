# Best Practices Overview

This section consolidates guidance that was scattered across the original documentation set: the project structure guide, advanced features chapter, display modes paper, and stock ticker example. Each child document below cites those existing sources without adding new opinions.

- `01-code-architecture.md` – Code organisation, resource management, and logging pointers.  
- `02-display-modes.md` – Text-only versus icon-only action guidance.  
- `03-deployment-readiness.md` – Packaging and release checklist items.  
- `04-security-and-performance.md` – Web service security, cleanup, and performance notes.  
- `05-testing-status.md` – Current state of testing documentation.
