# Quick Start Guide

The streamlined quick start below condenses the original `02-quick-start.md` into the essential setup, build, and customization steps without inventing new guidance.

## Prerequisites

- Windows 10+ or macOS with the Logitech/Loupedeck software running  
- Visual Studio 2022 or Visual Studio Code  
- .NET 8.0 SDK installed and on PATH  
- `LogiPluginTool` available as a global .NET tool

Verify your environment:

```bash
dotnet --version
LogiPluginTool --help
```

## 1. Install LogiPluginTool

```bash
dotnet tool install --global LogiPluginTool
```

Add the tool directory to PATH when necessary:

```bash
# macOS / Linux
echo 'export PATH="$PATH:$HOME/.dotnet/tools"' >> ~/.zshrc
source ~/.zshrc

# Windows (PowerShell)
setx PATH "$env:PATH;$env:USERPROFILE\.dotnet\tools"
```

## 2. Scaffold a Plugin

```bash
LogiPluginTool generate MyFirstPlugin
cd MyFirstPlugin/src
```

The generated project includes a plugin class, sample command, adjustment, helpers, and preconfigured packaging metadata.

## 3. Inspect the Generated Code

### Plugin

```csharp
public class MyFirstPlugin : Plugin
{
    public override Boolean UsesApplicationApiOnly => true;
    public override Boolean HasNoApplication => true;

    public MyFirstPlugin()
    {
        PluginLog.Init(this.Log);
        PluginResources.Init(this.Assembly);
    }
}
```

### Command

```csharp
public class CounterCommand : PluginDynamicCommand
{
    private Int32 _counter = 0;

    public CounterCommand()
        : base("Press Counter", "Counts button presses", "Commands")
    {
    }

    protected override void RunCommand(String actionParameter)
    {
        this._counter++;
        this.ActionImageChanged();
    }

    protected override String GetCommandDisplayName(String actionParameter, PluginImageSize imageSize)
        => $"Press Counter{Environment.NewLine}{this._counter}";
}
```

### Adjustment

```csharp
public class CounterAdjustment : PluginDynamicAdjustment
{
    private Int32 _counter = 0;

    public CounterAdjustment()
        : base("Tick Counter", "Counts rotation ticks", "Adjustments", hasReset: true)
    {
    }

    protected override void ApplyAdjustment(String actionParameter, Int32 diff)
    {
        this._counter += diff;
        this.AdjustmentValueChanged();
    }

    protected override void RunCommand(String actionParameter)
    {
        this._counter = 0;
        this.AdjustmentValueChanged();
    }
}
```

## 4. Build with Hot Reload

```bash
dotnet build
```

The post-build steps copy `package/metadata` assets into the output directory, create a `.link` file inside the Logi plugin folder, and trigger `loupedeck:plugin/<PluginName>/reload` for live testing.

## 5. Package and Verify

```bash
dotnet build --configuration Release
LogiPluginTool pack ./bin/Release ./MyFirstPlugin.lplug4
LogiPluginTool verify ./MyFirstPlugin.lplug4
LogiPluginTool install ./MyFirstPlugin.lplug4
```

## 6. Extend the Samples

### Custom Images

```csharp
protected override BitmapImage GetCommandImage(String actionParameter, PluginImageSize imageSize)
{
    using var builder = new BitmapBuilder(imageSize);
    builder.Clear(BitmapColor.Black);
    builder.DrawText($"Count\n{this._counter}", BitmapColor.White);
    return builder.ToImage();
}
```

### Action Parameters

```csharp
protected override void RunCommand(String actionParameter)
{
    var parameter = String.IsNullOrEmpty(actionParameter) ? "default" : actionParameter;
    PluginLog.Info($"Action executed with parameter: {parameter}");
}
```

### Embedded Resources

```csharp
protected override BitmapImage GetCommandImage(String actionParameter, PluginImageSize imageSize)
    => EmbeddedResources.ReadImage(EmbeddedResources.FindFile("myicon.png"));
```

## 7. Troubleshooting Checklist

- Ensure the Loupedeck software is running when linking or installing the plugin.  
- Re-run `dotnet build` after changing linkage or metadata files.  
- Use `open loupedeck:plugin/MyFirstPlugin/reload` (macOS) or `start loupedeck:plugin/MyFirstPlugin/reload` (Windows) to force reloads.  
- Confirm `.NET 8.0` is installed if you see compilation failures.  
- Verify `PluginApi.dll` is referenced through the generated MSBuild properties.

## Next Steps

- Deep dive into the project layout: `./03-project-structure.md`  
- Explore core concepts: `../02-Core-Concepts/01-api-fundamentals.md`  
- Configure dynamic action parameters: `../02-Core-Concepts/02-action-parameters.md`
