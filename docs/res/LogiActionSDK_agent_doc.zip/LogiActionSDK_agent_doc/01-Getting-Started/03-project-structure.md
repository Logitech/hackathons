# Project Structure Guide

This guide condenses the original `03-project-structure.md` to highlight the canonical layout, critical MSBuild settings, and practical organization tips for Logitech Actions SDK plugins.

## Standard Layout

```
MyPlugin/
├── MyPlugin.sln
├── src/
│   ├── .editorconfig
│   ├── Directory.Build.props
│   ├── MyPlugin.cs
│   ├── MyPlugin.csproj
│   ├── MyApplication.cs            # Optional application integration
│   ├── Actions/
│   │   ├── MyCommand.cs
│   │   └── MyAdjustment.cs
│   ├── Helpers/
│   │   ├── PluginLog.cs
│   │   └── PluginResources.cs
│   ├── Resources/                  # Embedded assets (icons, images, data)
│   └── package/
│       └── metadata/
│           ├── Icon256x256.png
│           └── LoupedeckPackage.yaml
└── bin/
    ├── Debug/
    └── Release/
```

## Core Files

### `MyPlugin.cs`

```csharp
public class MyPlugin : Plugin
{
    public override Boolean UsesApplicationApiOnly => true;
    public override Boolean HasNoApplication => true;

    public MyPlugin()
    {
        PluginLog.Init(this.Log);
        PluginResources.Init(this.Assembly);
    }

    public override void Load()    { /* Subscribe, start timers */ }
    public override void Unload()  { /* Dispose, unsubscribe */ }
    public override Boolean Install()  => true;
    public override Boolean Uninstall() => true;
}
```

### `MyPlugin.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>disable</Nullable>
    <RootNamespace>Loupedeck.MyPlugin</RootNamespace>

    <PluginApiDir Condition="$(OS) == 'Windows_NT'">
      C:\Program Files\Logi\LogiPluginService\
    </PluginApiDir>
    <PluginApiDir Condition="$(OS) != 'Windows_NT'">
      /Applications/Utilities/LogiPluginService.app/Contents/MonoBundle/
    </PluginApiDir>

    <BaseOutputPath>$([System.IO.Path]::GetFullPath('$(MSBuildThisFileDirectory)..\bin\'))</BaseOutputPath>
    <OutputPath>$(BaseOutputPath)$(Configuration)\bin\</OutputPath>
    <PluginShortName>MyPlugin</PluginShortName>
  </PropertyGroup>

  <ItemGroup>
    <Reference Include="PluginApi">
      <HintPath>$(PluginApiDir)PluginApi.dll</HintPath>
    </Reference>
  </ItemGroup>

  <Target Name="CopyPackage" AfterTargets="PostBuildEvent">
    <ItemGroup>
      <PackageFiles Include="package\**\*" />
    </ItemGroup>
    <Copy SourceFiles="@(PackageFiles)" DestinationFolder="$(OutputPath)..\%(RecursiveDir)" />
  </Target>

  <Target Name="PostBuild" AfterTargets="PostBuildEvent">
    <Exec Condition="$(OS) == 'Windows_NT'"
          Command="echo $(BaseOutputPath)$(Configuration)\ &gt; &quot;$(LocalAppData)\Logi\LogiPluginService\Plugins\$(ProjectName).link&quot;" />
    <Exec Condition="$(OS) != 'Windows_NT'"
          Command="echo $(BaseOutputPath)$(Configuration)\ &gt; ~/Library/Application\ Support/Logi/LogiPluginService/Plugins/$(ProjectName).link" />
    <Exec Condition="$(OS) == 'Windows_NT'" Command="start loupedeck:plugin/$(PluginShortName)/reload" ContinueOnError="true" />
    <Exec Condition="$(OS) != 'Windows_NT'" Command="open loupedeck:plugin/$(PluginShortName)/reload" ContinueOnError="true" />
  </Target>
</Project>
```

### `LoupedeckPackage.yaml` Essentials

```yaml
pluginName: MyPlugin
displayName: "My Plugin"
version: 1.0.0
author: "Developer"
supportedDevices:
    - LoupedeckCtFamily
minimumLoupedeckVersion: 6.0
license: MIT
homepageUrl: https://example.com
```

Include the file under `src/package/metadata/` so the post-build target copies it into the output folder alongside your DLL.

## Resource Organisation

- Store icons under `Resources/icons`, larger imagery under `Resources/images`, and supplementary assets (JSON, XML) inside `Resources/data`.  
- Mark assets as `EmbeddedResource` in the project file to load them via `EmbeddedResources.ReadImage` or standard stream APIs.  
- Maintain consistent namespaces such as `Loupedeck.MyPlugin.Actions.Commands` and `Loupedeck.MyPlugin.Services` to mirror folder layout.

## Build Modes

- `dotnet build` (Debug) keeps hot-reload enabled and writes `.link` files for iterative testing.  
- `dotnet build --configuration Release` produces optimized binaries for packaging.  
- Both configurations reuse the same `package/metadata` files through the `CopyPackage` target.

## Organisation Tips

Pulled directly from the original guide:

- Group related functionality into folders, keep files concise, and separate concerns.  
- Cache frequently used resources, dispose timers and watchers in `Unload()`, and log context-rich error messages.  
- Use `HasNoApplication`/`UsesApplicationApiOnly` to describe scope accurately and wire optional `ClientApplication` subclasses only when you need process detection.

## Related Reading

- API fundamentals: `../02-Core-Concepts/01-api-fundamentals.md`  
- Packaging details: `../02-Core-Concepts/03-package-and-metadata.md`  
- XML configuration options: `../03-Advanced-Features/02-xml-configuration.md`
