# Logitech Actions SDK – Curated Reference

This folder consolidates and deduplicates the Logitech Actions SDK documentation that was originally published under `docs/LogitechActionSDK`. Each section below pulls verbatim examples or summarises guidance from those source files without introducing new material.

## Folder Guide

- `01-Getting-Started` – SDK overview, quick-start workflow, and project layout fundamentals.
- `02-Core-Concepts` – Core API building blocks, action parameter patterns, and package metadata essentials.
- `03-Advanced-Features` – Lifecycle hooks, multistate commands, dynamic content, and XML driven layouts.
- `04-Examples` – Practical walkthroughs for the basic template and the Stocks (ticker) reference implementation.
- `05-Best-Practices` – Consolidated guidance on code quality, performance, logging, display modes, security, deployment, and current testing status.
- `06-Advanced-Topics` – Web application integration patterns and architecture deep-dives drawn from the original advanced topic papers.

For authoritative class signatures, lifecycle notes, and extended snippets, refer to the detailed markdown files within each directory. All code samples and checklists remain sourced from the original Logitech Actions SDK materials.

## Using These Docs with an Agent

When you want an AI assistant to build or update a plugin using this curated set, give concise prompts that point it at the right sections:

1. **Set the goal** – e.g. “Generate a stock ticker plugin that shows real-time prices.”
2. **Specify the references** – mention the files to consult, such as `01-Getting-Started/02-quick-start.md` for setup, `02-Core-Concepts/02-action-parameters.md` for configuration, or `04-Examples/02-stock-ticker-plugin.md` for end-to-end patterns.
3. **Call out assets** – if icon or metadata updates are needed, direct the agent to `02-Core-Concepts/03-package-and-metadata.md` and the relevant `Icon256x256.png`.
4. **Request deliverables** – tell the agent what to output (new C# files, updated YAML, documentation summaries, etc.).
5. **Ask for validation** – have the agent confirm build steps or tests (e.g. `dotnet build`, `LogiPluginTool verify`) so you can reproduce them locally.

### Agent Workflow Checklist

1. Ask agent to - Read the curated documentation and inspect the example projects that relate to your task.
2. Direct the agent to scaffold a new plugin with the desired name, build it, and install it into Option+ to confirm the workflow end to end.
3. Collaboratively clarify requirements by researching specifications (web search, prior art); use the Context7 MCP server when library documentation is needed.
4. Have the agent propose a step-by-step, test-driven plan before coding, and execute the work incrementally with builds/tests after each meaningful change.
