﻿namespace Loupedeck.Test4Plugin
{
    using System;

    public class Test4Application : ClientApplication
    {
        public Test4Application()
        {
        }
    }
}
