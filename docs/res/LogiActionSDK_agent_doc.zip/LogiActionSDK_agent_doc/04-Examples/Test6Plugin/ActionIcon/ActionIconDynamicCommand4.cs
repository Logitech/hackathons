﻿namespace Loupedeck.Test6Plugin
{
    using System;

    internal class ActionIconDynamicCommand4 : PluginDynamicCommand
    {
        public ActionIconDynamicCommand4()
            : base("Action Icon 4", "Action Icon 4 description", "Action Icon")
        {
        }
    }
}