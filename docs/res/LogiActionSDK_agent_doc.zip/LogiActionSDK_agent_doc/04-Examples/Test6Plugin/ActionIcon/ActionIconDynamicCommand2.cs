﻿namespace Loupedeck.Test6Plugin
{
    using System;

    internal class ActionIconDynamicCommand2 : PluginDynamicCommand
    {
        public ActionIconDynamicCommand2()
            : base("Action Icon 2", "Action Icon 2 description", "Action Icon")
        {
        }
    }
}