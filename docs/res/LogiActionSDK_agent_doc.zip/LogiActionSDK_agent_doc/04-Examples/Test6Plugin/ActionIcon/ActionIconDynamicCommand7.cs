﻿namespace Loupedeck.Test6Plugin
{
    using System;

    internal class ActionIconDynamicCommand7 : PluginDynamicCommand
    {
        public ActionIconDynamicCommand7()
            : base("Action Icon 7", "Action Icon 7 description", "Action Icon")
        {
        }
    }
}