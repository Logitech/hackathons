﻿namespace Loupedeck.Test6Plugin
{
    internal class DynamicAdjustment1 : DynamicAdjustmentBase
    {
        public DynamicAdjustment1() : base(1)
        {
        }
    }
}
