﻿namespace Loupedeck.Test6Plugin
{
    internal class DynamicAdjustment2 : DynamicAdjustmentBase
    {
        public DynamicAdjustment2(): base(2)
        {
        }
    }
}
