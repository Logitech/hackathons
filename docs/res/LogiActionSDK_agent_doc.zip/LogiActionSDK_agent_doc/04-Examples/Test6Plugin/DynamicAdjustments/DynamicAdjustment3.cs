﻿namespace Loupedeck.Test6Plugin
{
    internal class DynamicAdjustment3 : DynamicAdjustmentBase
    {
        public DynamicAdjustment3() : base(3)
        {
        }
    }
}
