﻿namespace Loupedeck.Test6Plugin
{
    internal class DynamicAdjustment5 : DynamicAdjustmentBase
    {
        public DynamicAdjustment5() : base(5)
        {
        }
    }
}
