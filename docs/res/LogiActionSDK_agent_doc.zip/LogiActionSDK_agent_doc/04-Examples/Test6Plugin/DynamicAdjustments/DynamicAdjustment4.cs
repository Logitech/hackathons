﻿namespace Loupedeck.Test6Plugin
{
    internal class DynamicAdjustment4 : DynamicAdjustmentBase
    {
        public DynamicAdjustment4() : base(4)
        {
        }
    }
}
